define(function(require) {
    require('./modules/rgbcolor');
    require('./modules/StackBlur');
    require('./modules/canvg');
    require('./modules/html2canvas');
});