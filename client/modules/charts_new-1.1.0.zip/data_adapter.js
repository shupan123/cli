define(function(require) {
	return {
		'name':'zhihuiya',
		'adapter': function(data) {
			return data;
		}
	}
})